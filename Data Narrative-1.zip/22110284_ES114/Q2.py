import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('books[1].csv')
df['average_rating'].plot(kind='hist',bins=180)
plt.xlabel('Average ratings')
plt.ylabel('Number of books')
plt.title('Ratings vs Books')
plt.show()
df['average_rating'].plot.kde()
plt.xlabel('Average ratings')
plt.title('Probability Desity Function of Ratings')
plt.show()
