import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
if __name__ == '__main__':

	df_usnews  = pd.read_csv('usnews.data', header=None)
df_usnews= df_usnews.replace("*", np.nan)
for i in range(4,35):
  df_usnews[i]=df_usnews[i].astype(float)

df1=df_usnews.sort_values(by=[34],ascending=False).head(5)
college=df1[1].drop_duplicates()
sat={}
colleges=[]
for c in college:
  m=df_usnews[df_usnews[1]==c]
  sat[c]=[m[8],m[4],m[9]]
  colleges.append(c)

f, (ax1, ax2,ax3) = plt.subplots(1, 3, sharey=True,figsize=(10,3))
ax1.tick_params(labelsize=6,labelrotation=75,axis='x')
ax2.tick_params(labelsize=6,labelrotation=75,axis='x')
ax3.tick_params(labelsize=6,labelrotation=75,axis='x')
ax1.stem(df1[1],df1[8])
ax2.stem(df1[1],df1[4])
ax3.stem(df1[1],df1[9])
ax1.set_title("First quartile - Math SAT")
ax2.set_title("Average Math SAT score")
ax3.set_title("Third quartile - Math SAT")
f.show()

f, (ax1, ax2,ax3) = plt.subplots(1, 3, sharey=True,figsize=(10,3))
ax1.tick_params(labelsize=6,labelrotation=75,axis='x')
ax2.tick_params(labelsize=6,labelrotation=75,axis='x')
ax3.tick_params(labelsize=6,labelrotation=75,axis='x')
ax1.stem(df1[1],df1[10])
ax2.stem(df1[1],df1[5])
ax3.stem(df1[1],df1[11])
ax1.set_title("First quartile - Verbal SAT")
ax2.set_title("Average Verbal SAT score")
ax3.set_title("Third quartile - Verbal SAT")
f.show()
