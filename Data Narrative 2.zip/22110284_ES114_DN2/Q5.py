import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

if __name__ == '__main__':

    df_aaup    = pd.read_csv('aaup.data', header=None)
 
df_aaup.columns=['FICE','College Name','State','Type','s_full professor','s_associate','s_assistant','s_all','comp_full professor','comp_associate','comp_assistant','comp_all','num_full','num_associate','num_assistant','num_instructor','num_all ranks']
df1=df_aaup['State'].value_counts().head(10).index.tolist()

fin=[]
a1,a2a,a2b,a7b=[],[],[],[]
for s in df1:
     m=df_aaup[df_aaup['State']==s]
     k=m['Type'].value_counts()
     a1.append(k['I'])
     a2a.append(k['IIA'])
     a2b.append(k['IIB'])
     if 'VIIB' in k.index :
       a7b.append(k['VIIB'])  
     else:
       a7b.append(0)
     fin.append(s)

plotdata = pd.DataFrame({
    "I":a1,
    "IIA":a2a,
    "IIB":a2b,"VIIB":a7b
    }, index=df1)
plotdata.plot(kind="bar",width=0.8,figsize=(8,5),color=('magenta','aqua', 'gold','blueviolet'), edgecolor= 'black')
plt.title("Types of College in Each state")
plt.xlabel("States")
plt.ylabel("Number of College")
plt.show()

