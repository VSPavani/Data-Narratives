import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
if __name__ == '__main__':

	df_usnews  = pd.read_csv('usnews.data', header=None)

df_usnews= df_usnews.replace("*", np.nan)
for i in range(4,35):
  df_usnews[i]=df_usnews[i].astype(float)
df_usnews['acceptance rate']=df_usnews[15]/df_usnews[14]
df_usnews['acceptance rate'].plot(kind='hist',bins=200)
plt.xlabel("Acceptance Rate")
plt.ylabel("Number of Colleges")
plt.title("Study of Acceptance rate at colleges")
plt.show()
df1=df_usnews.sort_values(by=['acceptance rate'],ascending=False).head(5)
states=df_usnews[2].drop_duplicates()
fin={}
for s in states:
  m=df_usnews[df_usnews[2]==s]
  fin[s]=[m['acceptance rate'].mean()]

final=pd.DataFrame.from_dict(fin,orient='index')
final=final.sort_values(by=[0]).head(10)
print("States with least acceptance rate")
print(final)
