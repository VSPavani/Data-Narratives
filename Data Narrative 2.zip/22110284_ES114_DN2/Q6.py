import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
if __name__ == '__main__':

	df_usnews  = pd.read_csv('usnews.data', header=None)
types=df_usnews[3].drop_duplicates()
df_usnews= df_usnews.replace("*", np.nan)
for i in range(21,35):
  df_usnews[i]=df_usnews[i].astype(float)
rbcost, addi_fee,tuition,book,per,ins=[],[],[],[],[],[]
for t in types:
  m=df_usnews[df_usnews[3]==t]
  rbcost.append(m[23].mean())
  addi_fee.append(m[26].mean())
  tuition.append(m[22].mean())
  book.append(m[27].mean())
  per.append(m[28].mean())
  ins.append(m[33].mean())
df_new=pd.DataFrame.from_dict({"Room and board ":rbcost, "Additional fees":addi_fee,"Out-of-state tuition":tuition,"Books":book,"Personal expense":per,"Instructional expenditure":ins})
df_new.plot.barh(stacked=True,color=("blueviolet","cyan","navy","springgreen","gold","royalblue"))

plt.ylabel("Type of College")
plt.xlabel("Expenditure")
plt.show()
