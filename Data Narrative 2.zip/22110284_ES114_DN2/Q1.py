import pandas as pd
import matplotlib.pyplot as plt
import pandas as pd

if __name__ == '__main__':

	df_aaup    = pd.read_csv('aaup.data', header=None)
 
df_aaup.columns=['FICE','College Name','State','Type','s_full professor','s_associate','s_assistant','s_all','comp_full professor','comp_associate','comp_assistant','comp_all','num_full','num_associate','num_assistant','num_instructor','num_all ranks']
df_aaup['expenditure']=df_aaup['s_all']*df_aaup['num_all ranks']+df_aaup['comp_all']*df_aaup['num_all ranks']

df_aaup['expenditure'].plot(kind='hist',bins=200)
plt.xlabel('Expenditure for faculty')
plt.ylabel('Number of colleges')
plt.title('Expenditure vs Colleges')
plt.show()

df1=df_aaup.sort_values(by=['expenditure'],ascending=False).head(10)
print(df1)
b1 = plt.barh(df1['College Name'],df1['s_all']*df1['num_all ranks'] , color="red")
b2 = plt.barh(df1['College Name'], df1['comp_all']*df1['num_all ranks'], left=df1['s_all']*df1['num_all ranks'], color="yellow")
plt.legend([b1, b2], ["Salaries", "Compensation"], title="College expenditure", loc="upper right")
plt.ylabel("Colleges")
plt.xlabel("Amount")
plt.title("Ten colleges with most expenditure")
plt.show()
b,c=0,0
for m in df_aaup['expenditure']:
	if m>500000:
		c+=1
	else:
		b+=1
print(b,c)
