import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
if __name__ == '__main__':

	df_usnews  = pd.read_csv('usnews.data', header=None)
df_usnews= df_usnews.replace("*", np.nan)
for i in range(4,35):
  df_usnews[i]=df_usnews[i].astype(float)
df_usnews['diff']=df_usnews[22]-df_usnews[21]
df_usnews['diff'].plot(kind='hist',bins=200)
plt.title("Colleges vs Difference in tuition")
plt.ylabel("Number of colleges")
plt.xlabel("Difference between in-state and out-of-state tuition")
plt.show()
df1=df_usnews.sort_values(by=[34],ascending=False).head(10)
names = df1.columns.tolist()
names[names.index(1)] = 'College Name'
df1.columns = names
names = df1.columns.tolist()
names[names.index('diff')] = 'Difference between tuition'
df1.columns = names
print (df1[['College Name','Difference between tuition']])
