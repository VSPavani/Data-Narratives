import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

if __name__ == '__main__':

    df_aaup    = pd.read_csv('aaup.data', header=None)
 
df_aaup.columns=['FICE','College Name','State','Type','s_full professor','s_associate','s_assistant','s_all','comp_full professor','comp_associate','comp_assistant','comp_all','num_full','num_associate','num_assistant','num_instructor','num_all ranks']
states=df_aaup['State'].drop_duplicates()
fin=[]
for s in states:
     m=df_aaup[df_aaup['State']==s]
     fin.append([s,sum(m['num_full'])])

fin.sort(key = lambda x: x[1],reverse=True)

final=fin[:10]
y=[]
mylabels=[]
explode=[]
for i in final:
    y.append(i[1])
    mylabels.append(i[0])
    print(i[0],i[1])
explode=[0.1,0,0,0,0,0,0,0,0,0]
total=sum(y)
plt.pie(y,labels=mylabels,autopct=lambda p: '{:.0f}'.format(p * total / 100),explode=explode)
plt.show()
