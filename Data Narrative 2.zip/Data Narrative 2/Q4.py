import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

if __name__ == '__main__':

    df_aaup    = pd.read_csv('aaup.data', header=None)
 
df_aaup.columns=['FICE','College Name','State','Type','s_full professor','s_associate','s_assistant','s_all','comp_full professor','comp_associate','comp_assistant','comp_all','num_full','num_associate','num_assistant','num_instructor','num_all ranks']

df_aaup= df_aaup.replace("*", np.nan)
df_aaup['s_full professor']=df_aaup['s_full professor'].astype(float)
df_aaup['s_associate']=df_aaup['s_associate'].astype(float)
df_aaup['s_assistant']=df_aaup['s_assistant'].astype(float)

df_aaup['comp_full professor']=df_aaup['comp_full professor'].astype(float)
df_aaup['comp_associate']=df_aaup['comp_associate'].astype(float)
df_aaup['comp_assistant']=df_aaup['comp_assistant'].astype(float)

df_aaup['benefit_full']=df_aaup['s_full professor']+df_aaup['comp_all']
df_aaup['benefit_asso']=df_aaup['s_associate']+df_aaup['comp_associate']
df_aaup['benefit_assi']=df_aaup['s_assistant']+df_aaup['comp_assistant']


df1=df_aaup.sort_values(by=['benefit_full'],ascending=False).head(10)
plt.bar(df1['College Name'], df1['s_full professor'] , color='aquamarine')
plt.bar(df1['College Name'], df1['comp_full professor'], bottom=df1['s_full professor'], color='b')
plt.xticks(fontsize=8,rotation=90)
plt.xlabel("Colleges")
plt.ylabel("Amount")
plt.legend(["Salary of professor","Compensation of professor"])
plt.title("Benefit of Full Professor at College")
plt.show()

df1=df_aaup.sort_values(by=['benefit_asso'],ascending=False).head(10)
plt.bar(df1['College Name'], df1['s_associate'] , color='aquamarine')
plt.bar(df1['College Name'], df1['comp_associate'], bottom=df1['s_associate'], color='b')
plt.xticks(fontsize=8,rotation=90)
plt.xlabel("Colleges")
plt.ylabel("Amount")
plt.legend(["Salary of professor","Compensation of professor"])
plt.title("Benefit of Associate Professor at College")
plt.show()

df1=df_aaup.sort_values(by=['benefit_assi'],ascending=False).head(10)
plt.bar(df1['College Name'], df1['s_assistant'] , color='aquamarine')
plt.bar(df1['College Name'], df1['comp_assistant'], bottom=df1['s_assistant'], color='b')
plt.xticks(fontsize=8,rotation=90)
plt.xlabel("Colleges")
plt.ylabel("Amount")
plt.legend(["Salary of professor","Compensation of professor"])
plt.title("Benefit of Assistant Professor at College")
plt.show()
