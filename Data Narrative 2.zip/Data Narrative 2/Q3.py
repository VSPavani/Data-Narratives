import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

if __name__ == '__main__':

    df_aaup    = pd.read_csv('aaup.data', header=None)
 
df_aaup.columns=['FICE','College Name','State','Type','s_full professor','s_associate','s_assistant','s_all','comp_full professor','comp_associate','comp_assistant','comp_all','num_full','num_associate','num_assistant','num_instructor','num_all ranks']
df_aaup= df_aaup.replace("*", np.nan)
types = df_aaup['Type'].drop_duplicates()

df_aaup['s_full professor']=df_aaup['s_full professor'].astype(float)
df_aaup['s_associate']=df_aaup['s_associate'].astype(float)
df_aaup['s_assistant']=df_aaup['s_assistant'].astype(float)
fin_full=[]
fin_assi=[]
fin_asso=[]
fin_s_full=[]
fin_s_assi=[]
fin_s_asso=[]
for t in types:
     m=df_aaup[df_aaup['Type']==t]
     fin_full.append(sum(m['num_full']))
     fin_assi.append(sum(m['num_assistant']))
     fin_asso.append(sum(m['num_associate']))
     fin_s_full.append(m['s_full professor'].mean(skipna=True))
     fin_s_assi.append(m['s_associate'].mean(skipna=True))
     fin_s_asso.append(m['s_assistant'].mean(skipna=True))

plotdata = pd.DataFrame({
    "Full Professors":fin_full,
    "Associate Professors":fin_asso,
    "Assistant Professors":fin_assi
    }, index=types)

plotdata.plot(kind="bar",figsize=(8,5),color=('blueviolet','gold', 'cyan'), edgecolor= 'black')
plt.title("Study of Professors at Colleges")
plt.xlabel("Types of College")
plt.ylabel("Number of professors")
plt.show()

plotdata = pd.DataFrame({
    "Full Professors":fin_s_full,
    "Associate Professors":fin_s_asso,
    "Assistant Professors":fin_s_assi
    }, index=types)

plotdata.plot(kind="bar",figsize=(8,5),color=('indigo','aqua', 'aquamarine'), edgecolor= 'black')
plt.title("Salary of Professors at Colleges")
plt.xlabel("Types of College")
plt.ylabel("Salary of professors")
plt.show()
