import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
if __name__ == '__main__':

	df_usnews  = pd.read_csv('usnews.data', header=None)
df_usnews= df_usnews.replace("*", np.nan)
for i in range(4,35):
  df_usnews[i]=df_usnews[i].astype(float)
a=df_usnews[17].mean()
b=df_usnews[18].mean()-df_usnews[17].mean()
c=100-df_usnews[18].mean()
plt.pie([a,b,c],labels=('Pct. new students from top 10% of H.S. class','Pct. new students from 10%-25% of H.S. class','Others'),colors=("orchid","cyan","blueviolet"),explode=(0.05,0.05,0.05),autopct=lambda p: '{:.0f}'.format(p * (a+b+c) / 100))
plt.show()
plt.pie([df_usnews[19].mean(),df_usnews[20].mean()],labels=('Fulltime graduates','Part-time graduates'), colors=('gold','red'),)
plt.show()
