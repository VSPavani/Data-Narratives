import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df = pd.read_csv('books[1].csv')
fin={}
df1= df['language_code'].drop_duplicates()
for x in df1 :
  m=df[df['language_code']==x]
  fin[x]= m['average_rating'].mean()
final=pd.Series(fin)
final.plot(kind='barh',figsize=(6,10))
plt.ylabel('Languages of the Book')
plt.xlabel('Ratings of Books')
plt.title('Average Rating of Books in Different Languages')
plt.show()
