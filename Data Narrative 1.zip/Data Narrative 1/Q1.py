import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('books[1].csv')
a=df['authors'].value_counts()
print(a.head(10))

a.head(10).plot(kind='pie')
plt.title("Number of books published by top ten authors")
plt.show()

a.head(10).plot(kind='bar')
plt.title("Number of books published by top ten authors")
plt.xlabel("Authors")
plt.ylabel("Number of books published")
plt.show()
