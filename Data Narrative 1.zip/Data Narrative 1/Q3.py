import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df = pd.read_csv('books[1].csv')
df1= df['authors'].drop_duplicates()
fin=[]
for x in df1 :
  m=df[df['authors']==x]
  if (m['original_publication_year'].min())>1800:
    fin.append(m['original_publication_year'].min())
fin1=np.array(fin)
final=pd.Series(fin1)
final.plot(kind='hist', bins=100)
plt.xlabel('Year of Debut of Authors')
plt.ylabel('Number of Authors')
plt.title('Authors vs Debut Year')
plt.show()

final.plot.kde()
plt.xlabel('Year of Debut of Authors')
plt.title('Probability Desity Function of Debut Year')
plt.show()

