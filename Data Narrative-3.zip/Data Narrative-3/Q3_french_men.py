import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df=pd.read_csv('/content/FrenchOpen-men-2013.csv')

sns.jointplot(x=df['FSP.1'], y=df['SSP.1'], kind="hex", color="#4CB391")
plt.show()

sns.jointplot(x=df['FSP.2'], y=df['SSP.2'], kind="hex", color="orchid")
plt.show()

values = df.values.tolist()

players=[]
for m in range(len(values)):
  if values[m][3]==1:
    players.append([values[m][0],values[m][6],values[m][8]])
  else :
     players.append([values[m][1],values[m][24],values[m][26]])

df_players=pd.DataFrame(players,columns=['0','1','2'])
# print(df_players)

types=df_players['0'].value_counts().head(10)
top_player=types.index.tolist()

fin=[]
fin2=[]
for t in top_player:
     m=df_players[df_players['0']==t]
     fin.append(m['1'].mean())
     fin2.append(m['2'].mean())

plotdata = pd.DataFrame({
    "First Serve Percentage":fin,
    "Second Serve Percentage":fin2
    }, index=types.index)
print(plotdata)
plotdata.plot(kind="bar",figsize=(5,4),color=('darkmagenta','pink'), edgecolor= 'black')
plt.title("Study of first and second serve")
plt.xlabel("Player")
plt.ylabel("Percentage")
plt.show()
