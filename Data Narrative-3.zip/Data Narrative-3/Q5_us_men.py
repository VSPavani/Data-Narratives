import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df=pd.read_csv('/content/USOpen-men-2013.csv')

values = df.values.tolist()
players=[]
for m in range(len(values)):
  if values[m][3]==1:
    players.append([values[m][0],values[m][16],values[m][17]])
  else :
     players.append([values[m][1],values[m][34],values[m][35]])
df_players=pd.DataFrame(players,columns=['0','1','2'])

types=df_players['0'].value_counts().head(10)
top_player=types.index.tolist()
prob=[]
fin=[]
fin2=[]
for t in top_player:
     m=df_players[df_players['0']==t]
     fin.append( m['1'].mean())
     fin2.append(m['2'].mean())
plotdata = pd.DataFrame({
    "Net Points Attempted by player ":fin2,
    "Net Points Won by player ":fin
    }, index=types.index)
print(plotdata)
plotdata.plot(kind="bar",figsize=(8,5),color=('firebrick','skyblue'), edgecolor= 'mistyrose')
plt.title("Study of Net points")
plt.xlabel("Players")
plt.ylabel("Points")
plt.show()

values = df.values.tolist()
players=[]
for m in range(len(values)):
    players.append([values[m][0],values[m][16],values[m][17]])
    players.append([values[m][1],values[m][34],values[m][35]])

df_players=pd.DataFrame(players,columns=['0','1','2'])

player = df_players['0'].drop_duplicates()
prob=[]
for t in player:
     m=df_players[df_players['0']==t]
     prob.append( m['1'].mean()/m['2'].mean())

plt.hist(prob,bins=40,color='mediumaquamarine')
plt.title("Study of Net points")
plt.xlabel("Ratio of net points won to net points attempted")
plt.ylabel("frequency")
plt.show()

