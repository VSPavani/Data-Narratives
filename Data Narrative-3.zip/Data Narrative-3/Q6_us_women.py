import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df=pd.read_csv('/content/USOpen-women-2013.csv')
values = df.values.tolist()
players=[]
for m in range(len(values)):
    players.append([values[m][0],values[m][10],values[m][12]])
    players.append([values[m][1],values[m][28],values[m][30]])

df_players=pd.DataFrame(players,columns=['0','1','2'])
print(df_players)

player = df_players['0'].drop_duplicates()
prob=[]
for t in player:
     m=df_players[df_players['0']==t]
     prob.append( m['1'].mean()/m['2'].mean())

plt.hist(prob,bins=20,color='teal')
plt.title("Study of Aces won and Winner")
plt.xlabel("Round in Tournament")
plt.ylabel("frequency")
plt.show()

df_prob=pd.Series(prob)
df_prob.plot.kde()
plt.title("Probability Density of the winner being ace")
plt.xlabel("Probability of winner earned being an ace")
plt.show()
     
