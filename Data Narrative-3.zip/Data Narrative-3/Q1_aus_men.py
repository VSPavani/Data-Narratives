import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df=pd.read_csv('/content/AusOpen-men-2013.csv')

values = df.values.tolist()

players=[]
for m in range(len(values)):
  if values[m][3]==1:
    players.append([values[m][0],values[m][11],values[m][13]])
  else :
     players.append([values[m][1],values[m][29],values[m][31]])

df_players=pd.DataFrame(players,columns=['0','1','2'])
# print(df_players)
print("Players who won most number of matches:")
print(df_players['0'].value_counts().head(5),'\n')

print("Players who won least number of matches:")
print(df_players['0'].value_counts().tail(5))

types=df_players['0'].value_counts().head(5)
top_player=types.index.tolist()

fin=[]
fin2=[]
for t in top_player:
     m=df_players[df_players['0']==t]
     fin.append(m['1'].mean())
     fin2.append(m['2'].mean())

plotdata = pd.DataFrame({
    "Double Faults committed by player":fin,
    "Unforced Errors committed by player":fin2
    }, index=types.index)
print(plotdata)
plotdata.plot(kind="bar",figsize=(5,4),color=('darkmagenta','pink'), edgecolor= 'black')
plt.title("Study of Double faults and Unforced Errors")
plt.xlabel("Player")
plt.ylabel("Number of errors and faults")
plt.show()

types=df_players['0'].value_counts().tail(5)
last_player=types.index.tolist()
fin=[]
fin2=[]
for t in last_player:
     m=df_players[df_players['0']==t]
     fin.append(m['1'].mean())
     fin2.append(m['2'].mean())

plotdata = pd.DataFrame({
    "Double Faults committed by player":fin,
    "Unforced Errors committed by player":fin2
    }, index=types.index)
print(plotdata)
plotdata.plot(kind="bar",figsize=(5,4),color=('blueviolet','cyan'), edgecolor= 'black')
plt.title("Study of Double faults and Unforced Errors")
plt.xlabel("Player")
plt.ylabel("Number of errors and faults")
plt.show()
