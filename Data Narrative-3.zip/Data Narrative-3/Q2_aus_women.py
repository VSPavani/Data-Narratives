import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df=pd.read_csv('/content/AusOpen-women-2013.csv')

round = df['Round'].drop_duplicates()
fin=[]
fin_w=[]
for t in round:
     m=df[df['Round']==t]
     fin.append((m['BPC.1'].mean()+m['BPC.2'].mean())/2)
     fin_w.append((m['BPW.1'].mean()+m['BPW.2'].mean())/2)

plotdata = pd.DataFrame({
    "Break Points won by player":fin,
    "Break Points created by player":fin_w,
    }, index=round)
print(plotdata)
plotdata.plot(kind="bar",figsize=(8,5),color=('plum','navy'), edgecolor= 'cornsilk')
plt.title("Study of Breakpoints")
plt.xlabel("Round in Tournaament")
plt.ylabel("Points")
plt.show()

plotdata['Ratio']=plotdata['Break Points won by player']/plotdata['Break Points created by player']
sns.relplot(data=plotdata, x='Round', y='Ratio',kind='line',color='darkmagenta')
plt.title("Study of Breakpoints Ratio")
plt.xlabel("Round in Tournament")
plt.ylabel("Ratio of break Points won to created")
plt.show()

sns.kdeplot(data=plotdata, x='Ratio', fill=True,color='palevioletred')
plt.title("Study of Breakpoints Ratio")
plt.xlabel("Ratio of break Points won to created")
plt.show()
