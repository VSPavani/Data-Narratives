import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df=pd.read_csv('/content/Wimbledon-men-2013.csv')

round = df['Round'].drop_duplicates()
fin=[]
fin_w=[]
for t in round:
     m=df[df['Round']==t]
     fin.append((m['UFE.1'].mean())+(m['UFE.2'].mean())/2)
plotdata = pd.DataFrame({
    "Unforced Errors":fin,
    }, index=round)
print(plotdata)
plotdata.plot(kind="bar",figsize=(5,4),color=('darkseagreen'), edgecolor='darkolivegreen')
plt.title("Study of Unforced errors with Rounds of matches")
plt.xlabel("Round in Tournament")
plt.ylabel("Unforced Errors")
plt.show()
explode=[0.1,0.1,0.1,0.1,0.1,0.1,0.1]
total=sum(fin)
color1=sns.color_palette("husl", 7)
plt.pie(fin,labels=round,autopct=lambda p: '{:.0f}'.format(p * total / 100),explode=explode,colors=color1)
plt.show()    
