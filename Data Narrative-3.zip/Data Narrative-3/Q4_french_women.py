import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df=pd.read_csv('/content/FrenchOpen-women-2013.csv')

round = df['Round'].drop_duplicates()
fin=[]
fin_w=[]
for t in round:
     m=df[df['Round']==t]
     values = m.values.tolist()
     c=0
     for i in range(len(values)):
       if (values[i][37]>values[i][19] and values[i][20]>values[i][38]) or (values[i][37]<values[i][19] and values[i][20]<values[i][38]):
         c+=1
     prob=c/len(values)
     fin.append(prob)
plotdata = pd.DataFrame({
    "Probability of player winning SET 2 based on SET 1":fin,
    }, index=round)
print(plotdata)
plotdata.plot(kind="bar",figsize=(5,4),color=('darkslategray'), edgecolor='cyan')
plt.title("Study of SET2 and SET1 relation")
plt.xlabel("Round in Tournament")
plt.ylabel("Probability of player winning SET 2 based on SET 1")
plt.show()

sns.relplot(data=plotdata, x='Round', y='Probability of player winning SET 2 based on SET 1',kind='line',color='navy')
plt.title("Study of SET2 and SET1 relation")
plt.xlabel("Round in Tournaament")
plt.ylabel("Probability of player winning SET 2 based on SET 1")
plt.show()
